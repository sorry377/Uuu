# NEXRA Executor

Roblox Lua Executor APK (Android)

## วิธี Build APK

### วิธีที่ 1: Android Studio (แนะนำ)
1. เปิด Android Studio
2. File → Open → เลือกโฟลเดอร์ `RobloxExecutor`
3. รอ Gradle sync เสร็จ
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

### วิธีที่ 2: Command Line
```bash
cd RobloxExecutor
chmod +x gradlew   # ถ้ามี gradlew
./gradlew assembleDebug
```

ถ้ายังไม่มี gradlew ให้ใช้ Android Studio สร้างก่อน หรือติดตั้ง Gradle แล้วรัน:
```bash
gradle wrapper
./gradlew assembleDebug
```

### ติดตั้งบนเครื่อง
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## ฟีเจอร์
- เลือก process Roblox
- โหลดข้อมูล + Anti-Ban / Anti-Kick
- หน้า Lua Executor
- รันสคริปต์ (client-side mock)

## หมายเหตุ
- Inject จริงต้องมี native layer + root/Frida
- Server-side ขึ้นกับ Remote abuse ของเกม
