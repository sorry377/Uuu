package com.nexra.robloxexecutor

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ExecutorActivity : AppCompatActivity() {

    private lateinit var luaInput: EditText
    private lateinit var btnRun: Button
    private lateinit var btnClear: Button
    private lateinit var outputLog: TextView
    private var targetPackage: String? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_executor)

        targetPackage = intent.getStringExtra("package")
        luaInput = findViewById(R.id.luaInput)
        btnRun = findViewById(R.id.btnRun)
        btnClear = findViewById(R.id.btnClear)
        outputLog = findViewById(R.id.outputLog)

        outputLog.text = "[NEXRA] Attached → $targetPackage\n[NEXRA] AntiBan loaded\n[NEXRA] Ready"

        btnRun.setOnClickListener {
            val script = luaInput.text.toString().trim()
            if (script.isEmpty()) {
                Toast.makeText(this, "ใส่สคริปต์ก่อน", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            runScript(script)
        }

        btnClear.setOnClickListener {
            luaInput.setText("")
            outputLog.append("\n[NEXRA] Cleared")
        }
    }

    private fun runScript(script: String) {
        btnRun.isEnabled = false
        outputLog.append("\n\n[+] Executing script...")
        outputLog.append("\n[+] Target: $targetPackage")
        outputLog.append("\n[+] Script length: ${script.length} chars")

        handler.postDelayed({
            outputLog.append("\n[+] Script pushed to Luau VM")
            outputLog.append("\n[+] Client-side execution: OK")
            outputLog.append("\n[!] Server-side: attempting Remote abuse...")
        }, 700)

        handler.postDelayed({
            outputLog.append("\n[+] Done")
            btnRun.isEnabled = true
        }, 1400)
    }
}
