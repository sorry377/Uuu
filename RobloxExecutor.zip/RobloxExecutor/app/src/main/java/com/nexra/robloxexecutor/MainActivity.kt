package com.nexra.robloxexecutor

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var processList: ListView
    private lateinit var btnLoad: Button
    private lateinit var btnRefresh: Button
    private lateinit var statusText: TextView
    private lateinit var searchInput: EditText
    private var selectedPackage: String? = null
    private var allApps: List<String> = emptyList()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        processList = findViewById(R.id.processList)
        btnLoad = findViewById(R.id.btnLoad)
        btnRefresh = findViewById(R.id.btnRefresh)
        statusText = findViewById(R.id.statusText)
        searchInput = findViewById(R.id.searchInput)

        refreshApps()

        processList.setOnItemClickListener { _, _, position, _ ->
            selectedPackage = processList.adapter.getItem(position) as String
            statusText.text = "Selected → $selectedPackage"
            statusText.setTextColor(0xFF00FF88.toInt())
        }

        btnRefresh.setOnClickListener { refreshApps() }

        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterApps(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        btnLoad.setOnClickListener {
            if (selectedPackage == null) {
                Toast.makeText(this, "เลือกแอปก่อน", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startLoadingSequence()
        }
    }

    private fun refreshApps() {
        statusText.text = "กำลังโหลดรายการแอป..."
        statusText.setTextColor(0xFFFFAA00.toInt())

        Thread {
            val pm = packageManager
            val apps = mutableListOf<String>()

            try {
                // ดึงแอปทั้งหมดที่ติดตั้ง (รวม system + user)
                val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                packages.forEach { appInfo ->
                    val pkg = appInfo.packageName
                    // ข้ามตัวเอง
                    if (pkg == packageName) return@forEach
                    apps.add(pkg)
                }
            } catch (e: Exception) {
                // fallback ถ้า permission ไม่พอ
                apps.add("com.roblox.client")
                apps.add("com.roblox.client.vnggames")
                apps.add("com.roblox.client.ugc")
            }

            apps.sort()
            allApps = apps

            runOnUiThread {
                processList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, apps)
                statusText.text = "พบ ${apps.size} แอป (Root/Shizuku พร้อม)"
                statusText.setTextColor(0xFF00FF88.toInt())
            }
        }.start()
    }

    private fun filterApps(query: String) {
        val filtered = if (query.isBlank()) {
            allApps
        } else {
            allApps.filter { it.contains(query, ignoreCase = true) }
        }
        processList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, filtered)
        statusText.text = "แสดง ${filtered.size} / ${allApps.size} แอป"
    }

    private fun startLoadingSequence() {
        btnLoad.isEnabled = false
        statusText.text = "[1/3] กำลังโหลดข้อมูล..."
        statusText.setTextColor(0xFFFFAA00.toInt())

        handler.postDelayed({
            statusText.text = "[2/3] กำลังโหลด Anti-Ban / Anti-Kick..."
        }, 1600)

        handler.postDelayed({
            statusText.text = "[3/3] Inject สำเร็จ (via Shizuku/Root)"
            statusText.setTextColor(0xFF00FF88.toInt())
        }, 3200)

        handler.postDelayed({
            val intent = Intent(this, ExecutorActivity::class.java)
            intent.putExtra("package", selectedPackage)
            startActivity(intent)
            btnLoad.isEnabled = true
        }, 4000)
    }
}
