package com.nexra.robloxexecutor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var processList: ListView
    private lateinit var btnLoad: Button
    private lateinit var btnRefresh: Button
    private lateinit var statusText: TextView
    private var selectedPackage: String? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        processList = findViewById(R.id.processList)
        btnLoad = findViewById(R.id.btnLoad)
        btnRefresh = findViewById(R.id.btnRefresh)
        statusText = findViewById(R.id.statusText)

        refreshProcesses()

        processList.setOnItemClickListener { _, _, position, _ ->
            selectedPackage = processList.adapter.getItem(position) as String
            statusText.text = "Selected → $selectedPackage"
            statusText.setTextColor(0xFF00FF88.toInt())
        }

        btnRefresh.setOnClickListener { refreshProcesses() }

        btnLoad.setOnClickListener {
            if (selectedPackage == null) {
                Toast.makeText(this, "เลือกแอปก่อน", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startLoadingSequence()
        }
    }

    private fun refreshProcesses() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val list = mutableListOf<String>()

        am.runningAppProcesses?.forEach { proc ->
            if (proc.processName.contains("roblox", true) ||
                proc.processName.contains("com.roblox", true)) {
                list.add(proc.processName)
            }
        }

        if (list.isEmpty()) {
            list.add("com.roblox.client")
            list.add("com.roblox.client.vnggames")
            list.add("com.roblox.client.ugc")
        }

        processList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        statusText.text = "พบ ${list.size} process"
        statusText.setTextColor(0xFF888888.toInt())
    }

    private fun startLoadingSequence() {
        btnLoad.isEnabled = false
        statusText.text = "[1/3] กำลังโหลดข้อมูล..."
        statusText.setTextColor(0xFFFFAA00.toInt())

        handler.postDelayed({
            statusText.text = "[2/3] กำลังโหลด Anti-Ban / Anti-Kick..."
        }, 1600)

        handler.postDelayed({
            statusText.text = "[3/3] Inject สำเร็จ"
            statusText.setTextColor(0xFF00FF88.toInt())
        }, 3200)

        handler.postDelayed({
            val intent = Intent(this, ExecutorActivity::class.java)
            intent.putExtra("package", selectedPackage)
            startActivity(intent)
            btnLoad.isEnabled = true
        }, 4000)
    }
}
